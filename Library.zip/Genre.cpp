
#include "Genre.h"

Genre::Genre(std::string id, std::string name, bool restricted, bool fictional) {
    this->id = id;
    this->name = name;
    this->restricted = restricted;
    this->fictional = fictional;
}
// Add other method implementations here, if any
