#include "Patron.h"

class User : public Patron {
 private:
  /* data */
 public:
  User(Patron* patron);
};