
#include "Patron.h"

// Add method implementations here, if any

Patron::Patron(int id, std::string name, std::string details,
               std::string password) {
  this->id = id;
  this->name = name;
  this->details = details;
  this->password = password;
}

Patron::Patron() {
  this->id = 0;
  this->name = "";
  this->details = "";
  this->password = "";
}

int Patron::getId() const { return id; }

std::string Patron::getName() const { return name; }

std::string Patron::getDetails() const { return details; }

bool Patron::checkLogin(std::string user, std::string password) {
  if (user == this->name && password == this->password) {
    return true;
  }
  return false;
}

std::vector<Book> Patron::getBooks() const { return books; }

std::vector<BorrowedBook> Patron::getHistory() const { return history; }