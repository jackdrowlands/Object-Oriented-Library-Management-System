
#include "Author.h"

Author::Author(std::string id, std::string name, std::string nationality, std::vector<std::string> aliases) {
    this->id = id;
    this->name = name;
    this->nationality = nationality;
    this->aliases = aliases;
}
// Add other method implementations here, if any
